# Generous Santa

- Category      : Web
- Author        : Elweth
- Difficulty    : Medium

The number of Santa's lunti has increased by 1337 this year, and there are a lot of them! Thanks to this, they've been able to give you some very, very nice gifts. If you can't find what you're looking for, you can even suggest gifts to him - maybe they'll make them in time!

# Deploy

```bash
docker compose up --build
```
